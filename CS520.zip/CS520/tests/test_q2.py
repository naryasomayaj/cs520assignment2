import pytest
from solutions.q2 import (
    separate_paren_groups_gpt_chain_of_thought,
    separate_paren_groups_deepseek_chain_of_thought,
    separate_paren_groups_deepseek_self_repair,
    separate_paren_groups_gpt_self_repair
)

solutions = [
    separate_paren_groups_gpt_chain_of_thought,
    separate_paren_groups_deepseek_chain_of_thought,
    separate_paren_groups_deepseek_self_repair,
    separate_paren_groups_gpt_self_repair,
]


def check(candidate):
    assert candidate("(()()) ((())) () ((())()())") == [
        "(()())", "((()))", "()", "((())()())"
    ]
    assert candidate("() (()) ((())) (((())))") == [
        "()", "(())", "((()))", "(((())))"
    ]
    assert candidate("(()(())((())))") == [
        "(()(())((())))"
    ]
    assert candidate("( ) (( )) (( )( ))") == [
        "()", "(())", "(()())"
    ]


def test_all_models():
    for f in solutions:
        check(f)
