

from solutions.q5 import (
    mean_absolute_deviation_gpt_chain_of_thought,
    mean_absolute_deviation_deepseek_chain_of_thought,
    mean_absolute_deviation_deepseek_self_repair,
    mean_absolute_deviation_gpt_self_repair,
)
solutions = [
    mean_absolute_deviation_gpt_chain_of_thought,
    mean_absolute_deviation_deepseek_chain_of_thought,
    mean_absolute_deviation_deepseek_self_repair,
    mean_absolute_deviation_gpt_self_repair,
]



def check(candidate):
    assert abs(candidate([1.0, 2.0, 3.0]) - 2.0 / 3.0) < 1e-6
    assert abs(candidate([1.0, 2.0, 3.0, 4.0]) - 1.0) < 1e-6
    assert abs(candidate([1.0, 2.0, 3.0, 4.0, 5.0]) - 6.0 / 5.0) < 1e-6

def test_all_models():
    for f in solutions:
        check(f)