import pytest
from solutions.q8 import (
    multiply_gpt_chain_of_thought,
    multiply_deepseek_chain_of_thought,
    multiply_deepseek_self_repair,
    multiply_gpt_self_repair,
)

solutions = [
    multiply_gpt_chain_of_thought,
    multiply_deepseek_chain_of_thought,
    multiply_deepseek_self_repair,
    multiply_gpt_self_repair,
]

def check_basic_operations(candidate):
    """Test basic functionality that works for all functions"""
    assert candidate(47, 52) == 14      # 7 * 2
    assert candidate(10, 20) == 0       # 0 * 0
    assert candidate(-13, 25) == 15     # 3 * 5
    assert candidate(99, 99) == 81      # 9 * 9
    assert candidate(123, -456) == 18   # 3 * 6
    
    # NEW TEST CASES:
    # Edge cases with zeros
    assert candidate(0, 0) == 0         # 0 * 0
    assert candidate(0, 5) == 0         # 0 * 5
    assert candidate(7, 0) == 0         # 7 * 0
    assert candidate(-10, 0) == 0       # 0 * 0
    assert candidate(0, -15) == 0       # 0 * 5
    
    # Single digit numbers
    assert candidate(7, 8) == 56        # 7 * 8
    assert candidate(-3, -9) == 27      # 3 * 9
    
    # Large numbers
    assert candidate(123456789, 987654321) == 9  # 9 * 1
    assert candidate(1000000000, 999999999) == 0 # 0 * 9
    
    # Mixed signs
    assert candidate(-47, 52) == 14     # 7 * 2
    assert candidate(47, -52) == 14     # 7 * 2
    assert candidate(-47, -52) == 14    # 7 * 2

def test_type_errors():
    """Test type validation for functions that have it"""
    # Test multiply_deepseek_self_repair type validation
    with pytest.raises(TypeError):
        multiply_deepseek_self_repair("not_int", 5)
    with pytest.raises(TypeError):
        multiply_deepseek_self_repair(5, "not_int")
    with pytest.raises(TypeError):
        multiply_deepseek_self_repair(3.14, 5)
    with pytest.raises(TypeError):
        multiply_deepseek_self_repair(5, [1, 2, 3])
    
    # Test multiply_gpt_self_repair type validation  
    with pytest.raises(TypeError):
        multiply_gpt_self_repair("not_int", 5)
    with pytest.raises(TypeError):
        multiply_gpt_self_repair(5, "not_int")
    with pytest.raises(TypeError):
        multiply_gpt_self_repair(3.14, 2.71)

def test_all_models():
    """Test all model implementations with basic operations"""
    for f in solutions:
        check_basic_operations(f)

# Make sure the type error tests run as separate test functions
# This ensures they're executed independently