import math
import pytest
from solutions.q3 import (
    truncate_number_gpt_chain_of_thought,
    truncate_number_deepseek_chain_of_thought,
    truncate_number_deepseek_self_repair,
    truncate_number_gpt_self_repair
)

solutions = [
    truncate_number_gpt_chain_of_thought,
    truncate_number_deepseek_chain_of_thought,
    truncate_number_deepseek_self_repair,
    truncate_number_gpt_self_repair,
]


def check(candidate):
    assert candidate(3.5) == 0.5
    assert abs(candidate(1.33) - 0.33) < 1e-6
    assert abs(candidate(123.456) - 0.456) < 1e-6







def test_all_models():
    for f in solutions:
        check(f)
