METADATA = {
    'author': 'jt',
    'dataset': 'test'
}

from solutions.q7 import (
    parse_nested_parens_gpt_chain_of_thought,
    parse_nested_parens_deepseek_chain_of_thought,
    parse_nested_parens_deepseek_self_repair,
    parse_nested_parens_gpt_self_repair,
)

solutions = [
    parse_nested_parens_gpt_chain_of_thought,
    parse_nested_parens_deepseek_chain_of_thought,
    parse_nested_parens_deepseek_self_repair,
    parse_nested_parens_gpt_self_repair,
]


def check(candidate):
    assert candidate("() (()) (()()) ((()))") == [1, 2, 2, 3]
    assert candidate("(()) ((())) () (((())))") == [2, 3, 1, 4]
    assert candidate("(()(())) ((()()))") == [3, 3]
    assert candidate("") == []
    assert candidate("()") == [1]


def test_all_models():
    for f in solutions:
        check(f)
