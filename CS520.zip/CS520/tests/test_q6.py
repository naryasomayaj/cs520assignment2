METADATA = {
    'author': 'jt',
    'dataset': 'test'
}

from solutions.q6 import (
    intersperse_gpt_chain_of_thought,
    intersperse_deepseek_chain_of_thought,
    intersperse_deepseek_self_repair,
    intersperse_gpt_self_repair,
)

solutions = [
    intersperse_gpt_chain_of_thought,
    intersperse_deepseek_chain_of_thought,
    intersperse_deepseek_self_repair,
    intersperse_gpt_self_repair,
]


def check(candidate):
    # basic interspersing
    assert candidate([1, 2, 3], 0) == [1, 0, 2, 0, 3]
    # single element: should return copy
    assert candidate([5], 9) == [5]
    # empty list: should return empty
    assert candidate([], 7) == []
    # longer list
    assert candidate([10, 20, 30, 40], -1) == [10, -1, 20, -1, 30, -1, 40]


def test_all_models():
    for f in solutions:
        check(f)
