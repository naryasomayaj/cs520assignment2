METADATA = {
    'author': 'jt',
    'dataset': 'test'
}

from solutions.q9 import (
    decimal_to_binary_gpt_chain_of_thought,
    decimal_to_binary_deepseek_chain_of_thought,
    decimal_to_binary_deepseek_self_repair,
    decimal_to_binary_gpt_self_repair,
)

solutions = [
    decimal_to_binary_gpt_chain_of_thought,
    decimal_to_binary_deepseek_chain_of_thought,
    decimal_to_binary_deepseek_self_repair,
    decimal_to_binary_gpt_self_repair,
]


def check(candidate):
    assert candidate(0) == "0"
    assert candidate(1) == "1"
    assert candidate(2) == "10"
    assert candidate(5) == "101"
    assert candidate(10) == "1010"
    assert candidate(13) == "1101"
    assert candidate(255) == "11111111"
    assert candidate(1024) == "10000000000"


def test_all_models():
    for f in solutions:
        check(f)
