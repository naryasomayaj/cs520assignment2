import pytest
from solutions.q4 import (
    below_zero_gpt_chain_of_thought,
    below_zero_deepseek_chain_of_thought,
    below_zero_deepseek_self_repair,
    below_zero_gpt_self_repair
)

solutions = [
    below_zero_gpt_chain_of_thought,
    below_zero_deepseek_chain_of_thought,
    below_zero_deepseek_self_repair,
    below_zero_gpt_self_repair,
]


def check(candidate):
    assert candidate([]) == False
    assert candidate([1, 2, -3, 1, 2, -3]) == False
    assert candidate([1, 2, -4, 5, 6]) == True
    assert candidate([1, -1, 2, -2, 5, -5, 4, -4]) == False
    assert candidate([1, -1, 2, -2, 5, -5, 4, -5]) == True
    assert candidate([1, -2, 2, -2, 5, -5, 4, -4]) == True


def test_all_models():
    for f in solutions:
        check(f)
