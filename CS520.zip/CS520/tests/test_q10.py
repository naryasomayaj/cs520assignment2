import pytest
import math
from solutions.q10 import (
    min_cost_path_gpt_chain_of_thought,
    min_cost_path_deepseek_chain_of_thought,
    min_cost_path_deepseek_self_repair,
    min_cost_path_gpt_self_repair,
)

solutions = [
    min_cost_path_gpt_chain_of_thought,
    min_cost_path_deepseek_chain_of_thought,
    min_cost_path_deepseek_self_repair,
    min_cost_path_gpt_self_repair,
]

class TestMinCostPathComprehensive:
    """Comprehensive test suite covering all DP paths and matrix configurations"""
    
    # ===== MATRIX SHAPE TESTS =====
    
    def test_1x1_matrix(self):
        """Test smallest possible matrix"""
        for candidate in solutions:
            assert candidate([[5]], 0, 0) == 5
            assert candidate([[0]], 0, 0) == 0
            assert candidate([[1.5]], 0, 0) == 1.5
    
    def test_1xN_matrices(self):
        """Test single row matrices (only right moves possible)"""
        for candidate in solutions:
            # 1x2
            assert candidate([[1, 2]], 0, 1) == 3
            # 1x3
            assert candidate([[1, 2, 3]], 0, 2) == 6
            # 1x4 with different values
            assert candidate([[5, 1, 3, 2]], 0, 3) == 11
            # 1x1 from larger row
            assert candidate([[1, 2, 3]], 0, 0) == 1
    
    def test_Nx1_matrices(self):
        """Test single column matrices (only down moves possible)"""
        for candidate in solutions:
            # 2x1
            assert candidate([[1], [2]], 1, 0) == 3
            # 3x1
            assert candidate([[1], [2], [3]], 2, 0) == 6
            # 4x1 with different values
            assert candidate([[5], [1], [3], [2]], 3, 0) == 11
            # 1x1 from larger column
            assert candidate([[1], [2], [3]], 0, 0) == 1
    
    def test_2x2_matrices(self):
        """Test all possible 2x2 scenarios"""
        for candidate in solutions:
            # Base case
            assert candidate([[1, 2], [3, 4]], 1, 1) == 7  # 1→2→4
            
            # Diagonal optimal
            diag_optimal = [[1, 10], [10, 2]]
            assert candidate(diag_optimal, 1, 1) == 3  # 1→2 via diagonal
            
            # Right-down vs down-right equality
            equal_path = [[1, 1], [1, 1]]
            assert candidate(equal_path, 1, 1) == 2
            
            # One very expensive path
            expensive_corner = [[1, 1], [1, 100]]
            assert candidate(expensive_corner, 1, 1) == 3  # 1→1→1→100 not taken
    
    def test_3x3_matrices(self):
        """Test comprehensive 3x3 scenarios covering all move combinations"""
        for candidate in solutions:
            # Standard case
            standard = [
                [1, 2, 3],
                [4, 5, 6],
                [7, 8, 9]
            ]
            # Path: 1→2→3→6→9 = 21 or 1→2→5→6→9 = 23 or 1→2→5→8→9 = 25
            # Actually minimum is 1→4→7→8→9 = 29? Let's compute properly:
            # The real minimum is 1→2→3→6→9 = 21
            assert candidate(standard, 2, 2) == 21
            
            # Diagonal favored
            diag_favored = [
                [1, 100, 100],
                [100, 2, 100],
                [100, 100, 3]
            ]
            assert candidate(diag_favored, 2, 2) == 6  # 1→2→3
            
            # Right move favored in first row
            right_favored = [
                [1, 1, 1],
                [100, 100, 100],
                [100, 100, 100]
            ]
            assert candidate(right_favored, 0, 2) == 3
            
            # Down move favored in first column
            down_favored = [
                [1, 100, 100],
                [1, 100, 100],
                [1, 100, 100]
            ]
            assert candidate(down_favored, 2, 0) == 3
    
    # ===== DP ALGORITHM PATH TESTS =====
    
    def test_dp_initialization_paths(self):
        """Test all DP table initialization paths"""
        for candidate in solutions:
            # Tests dp[0][0] initialization
            assert candidate([[7]], 0, 0) == 7
            
            # Tests first row initialization (j loop)
            first_row = [[1, 2, 3, 4, 5]]
            assert candidate(first_row, 0, 4) == 15
            
            # Tests first column initialization (i loop)
            first_col = [[1], [2], [3], [4], [5]]
            assert candidate(first_col, 4, 0) == 15
    
    def test_dp_min_selection_paths(self):
        """Test all min() function selection paths in DP"""
        for candidate in solutions:
            # Case where top is minimum
            top_min = [
                [1, 1, 1],
                [2, 1, 1],  # Comes from top=2, left=2, diag=2
                [5, 5, 1]   # Should pick top=1
            ]
            # Path analysis: 
            # dp[2][2] = cost[2][2] + min(dp[1][2], dp[2][1], dp[1][1])
            # = 1 + min(4, 7, 3) = 1 + 3 = 4
            result = candidate(top_min, 2, 2)
            assert result == 4
            
            # Case where left is minimum
            left_min = [
                [1, 2, 5],
                [2, 1, 1],  # Comes from top=3, left=3, diag=3  
                [5, 1, 1]   # Should pick left=6
            ]
            # dp[2][2] = 1 + min(dp[1][2]=4, dp[2][1]=6, dp[1][1]=3)
            # = 1 + 3 = 4
            result = candidate(left_min, 2, 2)
            assert result == 4
            
            # Case where diagonal is minimum
            diag_min = [
                [1, 5, 5],
                [5, 1, 5],  # Comes from top=6, left=6, diag=2
                [5, 5, 1]   # Should pick diagonal=3
            ]
            # dp[2][2] = 1 + min(dp[1][2]=7, dp[2][1]=7, dp[1][1]=3)
            # = 1 + 3 = 4
            result = candidate(diag_min, 2, 2)
            assert result == 4
    
    def test_boundary_conditions(self):
        """Test DP algorithm at various boundaries"""
        for candidate in solutions:
            matrix = [
                [1, 2, 3, 4],
                [5, 6, 7, 8],
                [9, 10, 11, 12],
                [13, 14, 15, 16]
            ]
            
            # Test all boundary positions
            assert candidate(matrix, 0, 0) == 1      # Start
            assert candidate(matrix, 0, 3) == 10     # First row end
            assert candidate(matrix, 3, 0) == 28     # First column end
            assert candidate(matrix, 1, 0) == 6      # First column middle
            assert candidate(matrix, 0, 1) == 3      # First row middle
            assert candidate(matrix, 1, 1) == 8      # 1→2→6 or 1→5→6
    
    # ===== DATA TYPE AND PRECISION TESTS =====
    
    def test_data_types(self):
        """Test with different numeric data types"""
        for candidate in solutions:
            # Integer matrix
            int_matrix = [[1, 2], [3, 4]]
            int_result = candidate(int_matrix, 1, 1)
            
            # Float matrix with same values
            float_matrix = [[1.0, 2.0], [3.0, 4.0]]
            float_result = candidate(float_matrix, 1, 1)
            
            # Results should be equivalent
            assert abs(int_result - float_result) < 1e-10
            
            # Mixed int/float
            mixed_matrix = [[1, 2.5], [3.5, 4]]
            mixed_result = candidate(mixed_matrix, 1, 1)
            assert mixed_result == 8.0  # 1→2.5→4
    
    def test_precision_handling(self):
        """Test floating point precision in min() operations"""
        for candidate in solutions:
            # Very close values that test floating point comparison
            close_values = [
                [1.0, 1.0000000001, 1.0000000002],
                [1.0000000003, 1.0000000004, 1.0000000005],
                [1.0000000006, 1.0000000007, 1.0000000008]
            ]
            result = candidate(close_values, 2, 2)
            expected = 3.0000000018  # Sum of diagonal
            assert abs(result - expected) < 1e-6
    
    # ===== EDGE CASE COMBINATIONS =====
    
    def test_zero_and_negative_costs(self):
        """Test matrices with zero and potentially negative costs"""
        for candidate in solutions:
            # All zeros
            zeros = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]
            assert candidate(zeros, 2, 2) == 0
            
            # Mixed with zeros
            mixed_zeros = [[1, 0, 2], [0, 1, 0], [2, 0, 1]]
            result = candidate(mixed_zeros, 2, 2)
            # Minimum path: 1→0→0→0→1 = 2
            assert result == 2
    
    def test_large_value_matrices(self):
        """Test with very large values that might cause overflow"""
        for candidate in solutions:
            large_vals = [
                [1e10, 2e10, 3e10],
                [4e10, 5e10, 6e10],
                [7e10, 8e10, 9e10]
            ]
            result = candidate(large_vals, 2, 2)
            assert result > 1e10
    
    # ===== ASYMMETRIC MATRIX TESTS =====
    
    def test_rectangular_matrices(self):
        """Test non-square matrices"""
        for candidate in solutions:
            # 2x3 matrix
            wide_matrix = [
                [1, 2, 3],
                [4, 5, 6]
            ]
            assert candidate(wide_matrix, 1, 2) == 12  # 1→2→3→6
            
            # 3x2 matrix  
            tall_matrix = [
                [1, 2],
                [3, 4],
                [5, 6]
            ]
            assert candidate(tall_matrix, 2, 1) == 13  # 1→2→4→6
    
    def test_minimal_path_scenarios(self):
        """Test scenarios that force specific minimal paths"""
        for candidate in solutions:
            # Forces only right then down
            right_then_down = [
                [1, 1, 1],
                [100, 100, 2],
                [100, 100, 3]
            ]
            # Path must be: 1→1→1→2→3 = 8
            assert candidate(right_then_down, 2, 2) == 8
            
            # Forces only down then right
            down_then_right = [
                [1, 100, 100],
                [1, 100, 100],
                [1, 2, 3]
            ]
            # Path must be: 1→1→1→2→3 = 8
            assert candidate(down_then_right, 2, 2) == 8
            
            # Forces diagonal path
            force_diagonal = [
                [1, 100, 100],
                [100, 2, 100],
                [100, 100, 3]
            ]
            # Only possible path: 1→2→3 = 6
            assert candidate(force_diagonal, 2, 2) == 6

    # ===== VALIDATION TESTING =====
    
    def test_validation_functions(self):
        """Test the validation in self-repair functions"""
        # Test min_cost_path_deepseek_self_repair validation
        with pytest.raises((TypeError, ValueError)):
            min_cost_path_deepseek_self_repair("invalid", 0, 0)
        
        with pytest.raises(ValueError):
            min_cost_path_deepseek_self_repair([], 0, 0)
        
        with pytest.raises(ValueError):
            min_cost_path_deepseek_self_repair([[1], [2, 3]], 0, 0)
        
        with pytest.raises((IndexError, ValueError)):
            min_cost_path_deepseek_self_repair([[1, 2], [3, 4]], -1, 0)
        
        # Test min_cost_path_gpt_self_repair validation
        with pytest.raises(ValueError):
            min_cost_path_gpt_self_repair(None, 0, 0)
        
        with pytest.raises(ValueError):
            min_cost_path_gpt_self_repair([[1], [2, 3]], 0, 0)

def test_all_functions_basic_compatibility():
    """Ensure all functions work with basic cases"""
    basic_matrix = [[1, 2], [3, 4]]
    for candidate in solutions:
        result = candidate(basic_matrix, 1, 1)
        assert result == 7

# Run all comprehensive tests
if __name__ == "__main__":
    pytest.main([__file__, "-v"])