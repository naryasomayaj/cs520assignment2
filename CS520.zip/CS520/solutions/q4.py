from typing import List, Union
import math


def below_zero_gpt_chain_of_thought(operations: List[int]) -> bool:
    """
    Given a list of deposit (+) and withdrawal (-) operations on a bank account
    starting at zero balance, detect if the balance ever goes below zero.
    
    :param transactions: list of numbers (positive for deposits, negative for withdrawals)
    :return: True if balance falls below zero at any point, False otherwise
    """
    balance = 0
    for amount in operations:
        balance += amount
        if balance < 0:
            return True
    return False

def below_zero_deepseek_chain_of_thought(operations: List[int]) -> bool:
    """
    Detect if account balance ever falls below zero during a sequence of operations.
    
    Args:
        operations: List of numbers representing deposits (positive) and withdrawals (negative)
        
    Returns:
        bool: True if balance ever goes negative, False otherwise
    """
    balance = 0
    
    for operation in operations:
        balance += operation
        
        # Check if balance went negative after this operation
        if balance < 0:
            return True
    
    return False

def below_zero_deepseek_self_repair(operations: List[int]) -> bool:
    """
    Final robust implementation to check if bank account balance goes below zero.
    """
    # Input validation
    if not isinstance(operations, list):
        raise TypeError(f"Input must be a list, got {type(operations).__name__}")
    
    balance = 0
    
    for operation in operations:
        if not isinstance(operation, (int, float)):
            raise ValueError(f"All operations must be numbers, got {type(operation).__name__}")
        
        balance += operation
        
        if balance < 0:
            return True
    
    return False

def below_zero_gpt_self_repair(operations: List[int]) -> bool:

    Number = Union[int, float]

    """
    Iterate through `transactions` and detect whether the running balance
    ever becomes negative. The initial balance is 0.

    Parameters
    - transactions: iterable of numbers (int/float). Can be a list, generator, etc.
    - return_point: if True, return (True, index, balance_at_negative) when negative,
                    otherwise return simply True/False.

    Returns
    - If return_point is False: boolean (True if balance fell below zero at some point).
    - If return_point is True: tuple (went_negative: bool, index: Optional[int], balance: Optional[float]).
      If never negative, index and balance will be None.

    Raises
    - TypeError if an element is not int/float.
    - ValueError if an element is NaN or infinite.
    """
    return_point = False  # Set to True if you want index and balance at first negative point
    balance = 0.0
    for idx, tx in enumerate(operations):
        # validate type
        if not isinstance(tx, (int, float)):
            raise TypeError(f"Transaction at index {idx} is not numeric: {type(tx)}")

        # coerce to float for consistent behavior
        value = float(tx)

        # validate finiteness
        if not math.isfinite(value):
            raise ValueError(f"Transaction at index {idx} is not finite: {tx!r}")

        # update balance
        balance += value

        # check if negative
        if balance < 0:
            if return_point:
                return True, idx, balance
            return True

    # never negative
    if return_point:
        return False, None, None
    return False

