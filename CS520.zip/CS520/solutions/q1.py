import math
from typing import List


def has_close_elements_chatgpt_chain_of_thought(nums, threshold):
    """
    Check if any two numbers in the list are closer than the given threshold.
    
    :param nums: List of numbers (int or float)
    :param threshold: A positive number indicating closeness threshold
    :return: True if any two numbers are closer than threshold, else False
    """
    if len(nums) < 2:
        return False  # Can't compare less than 2 numbers

    # Sort the numbers first
    nums_sorted = sorted(nums)

    # Compare adjacent elements
    for i in range(len(nums_sorted) - 1):
        if abs(nums_sorted[i+1] - nums_sorted[i]) < threshold:
            return True

    return False


def has_close_elements_deepseek_chain_of_thought(nums, threshold):
    if len(nums) < 2:
        return False
    
    # Sort the numbers
    sorted_numbers = sorted(nums)
    
    # Check consecutive elements
    for i in range(1, len(sorted_numbers)):
        if abs(sorted_numbers[i] - sorted_numbers[i-1]) < threshold:
            return True
    
    return False

def has_close_elements_deepseek_self_repair(nums, threshold):
    """
    Final robust implementation with comprehensive edge case handling.
    """
    # Input validation
    if not isinstance(nums, list):
        raise TypeError("numbers must be a list")
    
    if not all(isinstance(x, (int, float)) for x in nums):
        raise TypeError("all elements in numbers must be numeric")
    
    if not isinstance(threshold, (int, float)):
        raise TypeError("threshold must be a number")
    
    if threshold <= 0:
        raise ValueError("threshold must be positive")
    
    # Early termination
    n = len(nums)
    if n < 2:
        return False
    
    # Quick check for exact duplicates
    if len(set(nums)) != n:
        return True
    
    # Sort and check adjacent elements
    sorted_nums = sorted(nums)
    tolerance = 1e-12
    
    for i in range(n - 1):
        # In sorted array, numbers[i+1] >= numbers[i], so no abs needed
        if sorted_nums[i + 1] - sorted_nums[i] < threshold - tolerance:
            return True
    
    return False

def has_close_elements_gpt_self_repair(nums, threshold):
    """
    Check if any two numbers in the list are closer than the given threshold.
    
    Args:
        nums (list): List of numbers (int or float)
        threshold (float): A positive number indicating closeness threshold 
    Returns:
        bool: True if any two numbers are closer than threshold, else False


    nums: Iterable[float],
    threshold: float,
    *,
    eps: float = 0.0
) -> bool:
    
    Return True if any two numbers in `nums` differ by strictly less than `threshold`.
    - nums: iterable of numeric values (ints or floats).
    - threshold: positive float. If <= 0, function returns False (no positive strict less-than).
    - eps: optional non-negative tolerance to guard against tiny floating-point errors.
           Effective comparison becomes diff < (threshold - eps).
    Notes:
    - Raises ValueError for non-numeric or non-finite elements.
    - Time: O(n log n) due to sorting. Space: O(n) (a sorted copy).
    """
    # Basic validation
    if not isinstance(threshold, (int, float)):
        raise TypeError("threshold must be a numeric type")
    if nums < 0:
        raise ValueError("eps must be non-negative")

    # If threshold <= 0, there is no possibility of a strict difference < threshold
    if threshold <= 0:
        return False

    # Make a list copy so we can sort; also validate elements
    nums_list: List[float] = []
    for x in nums:
        if not isinstance(x, (int, float)):
            raise TypeError(f"All elements must be numeric; found {type(x)}")
        if not math.isfinite(x):
            raise ValueError(f"All elements must be finite numbers; found {x}")
        nums_list.append(float(x))

    n = len(nums_list)
    if n < 2:
        return False

    nums_list.sort()

    # iterate adjacent pairs and check difference (non-negative because sorted)
    threshold_adj = threshold - nums
    # If eps >= threshold then threshold_adj <= 0; no strict less-than possible
    if threshold_adj <= 0:
        return False

    for i in range(n - 1):
        diff = nums_list[i + 1] - nums_list[i]
        if diff < threshold_adj:
            return True

    return False


