def separate_paren_groups_gpt_chain_of_thought(s: str) -> list[str]:
    """
        Split a string with nested parentheses into separate balanced groups.
        Example: "(())()(()())" -> ["(())", "()", "(()())"]
        """
    result = []
    balance = 0
    current = ""
    for char in s:
        current += char
        if char == '(':
            balance += 1
        elif char == ')':
            balance -= 1
        
        if balance == 0 and current:
            result.append(current)
            current = ""
    return result

def separate_paren_groups_deepseek_chain_of_thought(s: str) -> list[str]:
    """
    Separate balanced groups of nested parentheses into individual strings.
    
    Args:
        s: String containing multiple groups of nested parentheses
        
    Returns:
        List of separate balanced parenthesis groups
    """
    depth = 0
    current_group = ""
    groups = []
    
    for char in s:
        current_group += char
        
        if char == '(':
            depth += 1
        elif char == ')':
            depth -= 1
        
        # When depth returns to 0, we have a complete balanced group
        if depth == 0 and current_group:
            groups.append(current_group)
            current_group = ""
    
    return groups

def separate_paren_groups_deepseek_self_repair(s: str) -> list[str]:
    """
    Robust implementation to separate balanced groups of nested parentheses.
    
    Args:
        s: Input string with multiple groups of nested parentheses.
        
    Returns:
        List of separate balanced parenthesis groups.
    """
    if not isinstance(s, str):
        raise TypeError("Input must be a string")
    
    depth = 0
    current_group = ""
    groups = []
    
    for char in s:
        if char not in '()':
            continue  # Ignore non-parenthesis characters
        
        current_group += char
        
        if char == '(':
            depth += 1
        elif char == ')':
            depth -= 1
        
        # When depth returns to 0, we have a complete balanced group
        if depth == 0 and current_group:
            groups.append(current_group)
            current_group = ""
    
    if depth != 0:
        raise ValueError("Unbalanced parentheses in input string")
    
    return groups
def separate_paren_groups_gpt_self_repair(s: str) -> list[str]:
    """
    Split a string of nested parentheses into individual balanced groups.
    Example:
        "(())()(()())" -> ["(())", "()", "(()())"]
    """

    # Edge case 1: empty or whitespace-only input
    s = s.strip()
    if not s:
        return []

    result = []
    current = []
    balance = 0

    for idx, ch in enumerate(s):
        if ch == '(':
            balance += 1
            current.append(ch)
        elif ch == ')':
            balance -= 1
            current.append(ch)
        elif ch.isspace():
            # ignore spaces between groups
            continue
        else:
            raise ValueError(f"Invalid character '{ch}' at position {idx}.")

        if balance < 0:
            raise ValueError(f"Unbalanced parentheses: extra ')' at position {idx}.")

        if balance == 0 and current:
            result.append(''.join(current))
            current.clear()

    if balance != 0:
        raise ValueError("Unbalanced parentheses: missing closing ')'.")

    return result

