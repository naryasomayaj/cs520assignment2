from typing import List


def intersperse_gpt_chain_of_thought(numbers: List[int], delimeter: int) -> List[int]:
    """
    Insert a given delimiter between every two consecutive elements
    in the input list `numbers`.

    Example:
        numbers = [1, 2, 3]
        delimiter = 0
        → [1, 0, 2, 0, 3]
    """
    if len(numbers) <= 1:
        return numbers[:]  # Return copy to avoid modifying input
    
    result = []
    
    for i in range(len(numbers) - 1):
        result.append(numbers[i])
        result.append(delimeter)
    
    # Append last number without delimiter after it
    result.append(numbers[-1])
    
    return result

def intersperse_deepseek_chain_of_thought(numbers: List[int], delimiter: int) -> List[int]:
    """
    More efficient version that pre-allocates the result list.
    """
    n = len(numbers)
    if n <= 1:
        return numbers[:]
    
    # Pre-allocate result list for better performance
    result = [None] * (2 * n - 1)
    
    # Fill the result list
    for i in range(n - 1):
        result[2 * i] = numbers[i]      # Original element
        result[2 * i + 1] = delimiter   # Delimiter
    
    result[-1] = numbers[-1]  # Last element
    
    return result

def intersperse_deepseek_self_repair(numbers: List[int], delimiter: int) -> List[int]:  
    """
    Final robust implementation of intersperse function.
    """
    # Input validation
    if not isinstance(numbers, list):
        raise TypeError(f"Input must be a list, got {type(numbers).__name__}")
    
    for i, x in enumerate(numbers):
        if not isinstance(x, int):
            raise ValueError(f"All elements must be integers, got {type(x).__name__} at index {i}")
    
    if not isinstance(delimiter, int):
        raise TypeError(f"Delimiter must be an integer, got {type(delimiter).__name__}")
    
    n = len(numbers)
    if n <= 1:
        return numbers[:]
    
    result = [None] * (2 * n - 1)
    
    for i in range(n - 1):
        result[2 * i] = numbers[i]
        result[2 * i + 1] = delimiter
    
    result[-1] = numbers[-1]
    
    return result

def intersperse_gpt_self_repair(numbers: List[int], delimiter: int) -> List[int]:

    """
    Return a new list with `delimiter` inserted between consecutive elements of `numbers`.

    Example:
        insert_delimiter([1, 2, 3], 0) -> [1, 0, 2, 0, 3]
    """
    # Convert iterable to list once (safe for generators)
    nums = list(numbers)

    # Edge cases
    if not nums:
        return []
    if len(nums) == 1:
        # Return a shallow copy to avoid modifying input
        return nums.copy()

    # Efficient O(n) construction using append
    result = []
    last_index = len(nums) - 1
    for i, value in enumerate(nums):
        result.append(value)
        if i < last_index:
            result.append(delimiter)

    return result

