import math
from typing import List, Union


def mean_absolute_deviation_gpt_chain_of_thought(numbers: List[float]) -> float:
    """
    Compute the Mean Absolute Deviation (MAD) around the mean.
    
    :param data: list of numbers
    :return: float representing MAD value
    """
    if not numbers:
        raise ValueError("Input data list cannot be empty.")
    
    # Step 1: Calculate the mean
    mean_value = sum(numbers) / len(numbers)
    
    # Step 2: Calculate absolute deviations
    absolute_deviations = [abs(x - mean_value) for x in numbers]
    
    # Step 3: Compute mean of absolute deviations
    mad = sum(absolute_deviations) / len(numbers)
    
    return mad

def mean_absolute_deviation_deepseek_chain_of_thought(numbers: List[float]) -> float:
    """
    Calculate Mean Absolute Deviation around the mean of the dataset.
    
    Args:
        data: List of numbers
    Returns:
        
    float: Mean Absolute Deviation
        
    Raises:
        ValueError: If input list is empty
    """
    if not numbers:
        raise ValueError("Input list cannot be empty")
    
    n = len(numbers)
    
    # Step 1: Calculate mean
    mean = sum(numbers) / n
    
    # Step 2: Calculate sum of absolute deviations
    sum_absolute_deviations = sum(abs(value - mean) for value in numbers)
    
    # Step 3: Calculate MAD
    mad = sum_absolute_deviations / n
    
    return mad

def mean_absolute_deviation_deepseek_self_repair(numbers: List[float]) -> float:
    """
    Final robust implementation of Mean Absolute Deviation.
    """
    # Input validation
    if not isinstance(numbers, list):
        raise TypeError(f"Input must be a list, got {type(numbers).__name__}")
    
    n = len(numbers)
    if n == 0:
        raise ValueError("Cannot compute MAD for empty list")
    
    # Validate all elements
    for i, x in enumerate(numbers):
        if not isinstance(x, (int, float)):
            raise TypeError(f"Element at index {i} must be numeric, got {type(x).__name__}")
        if math.isnan(x):
            raise ValueError(f"Element at index {i} is NaN")
        if math.isinf(x):
            raise ValueError(f"Element at index {i} is infinity")
    
    # Quick returns
    if n == 1:
        return 0.0
    
    # Check for constant dataset (all values equal)
    if all(x == numbers[0] for x in numbers):
        return 0.0
    
    # Calculate using optimized approach
    try:
        # Try high-precision method first
        return _mad_high_precision_final(numbers, n)
    except (OverflowError, MemoryError):
        # Fall back to stable method if precision method fails
        return _mad_stable_final(numbers, n)

def _mad_high_precision_final(numbers, n):
    """High precision implementation with comprehensive error handling."""
    # Calculate mean with high precision
    total = math.fsum(numbers)
    mean = total / n
    
    # Calculate sum of absolute deviations with generator to save memory
    sum_abs_dev = math.fsum(abs(x - mean) for x in numbers)
    mad = sum_abs_dev / n
    
    # Final cleanup
    return 0.0 if abs(mad) < 1e-12 else mad

def _mad_stable_final(numbers, n):
    """Stable implementation for problematic datasets."""
    # Use iterative mean calculation for better stability
    mean = 0.0
    for i, x in enumerate(numbers):
        mean += (x - mean) / (i + 1)
    
    # Calculate MAD
    sum_abs_dev = 0.0
    for x in numbers:
        sum_abs_dev += abs(x - mean)
    
    mad = sum_abs_dev / n
    return 0.0 if abs(mad) < 1e-12 else mad

Number = Union[int, float]

def mean_absolute_deviation_gpt_self_repair(numbers: List[float]) -> float:

    """
    Compute the Mean Absolute Deviation (MAD) around the mean.
    
    Parameters:
        values: Iterable of numeric values (ints/floats)
    
    Returns:
        The mean absolute deviation (float)
    
    Raises:
        ValueError: if input is empty or contains NaN/Inf
        TypeError: if non-numeric items are present
    """

    # Convert to list to allow multiple passes safely
    vals = list(numbers)

    if not vals:
        raise ValueError("Empty input sequence — cannot compute MAD.")

    # Validate elements
    for i, x in enumerate(vals):
        if not isinstance(x, (int, float)):
            raise TypeError(f"Element at index {i} is not numeric: {type(x).__name__}")
        if not math.isfinite(x):
            raise ValueError(f"Element at index {i} is not finite: {x!r}")

    n = len(vals)

    # Compute mean (O(n))
    mean_val = sum(vals) / n

    # Compute mean absolute deviation (O(n))
    mad = sum(abs(x - mean_val) for x in vals) / n

    return mad
