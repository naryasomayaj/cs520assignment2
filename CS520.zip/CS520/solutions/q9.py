def decimal_to_binary_gpt_chain_of_thought(decimal):
    """
    Convert a non-negative integer from decimal to binary string representation.
    
    Example:
        10 -> "1010"
        0  -> "0"
        13 -> "1101"
    """
    if decimal == 0:
        return "0"
    
    binary_digits = []
    
    while decimal > 0:
        remainder = decimal % 2
        binary_digits.append(str(remainder))
        decimal //= 2  # integer division
    
    # Digits are in reverse order; reverse to get correct binary representation
    binary_digits.reverse()
    
    return "".join(binary_digits)


def decimal_to_binary_deepseek_chain_of_thought(decimal: int) -> str:
    """
    Convert a non-negative integer from decimal to its binary string representation.
    
    Args:
        decimal: Non-negative integer to convert
    Returns:
        Binary string representation of the integer 
    """
    if decimal == 0:
        return "0"
    
    binary_digits = []
    
    while decimal > 0:
        remainder = decimal % 2
        binary_digits.append(str(remainder))
        decimal //= 2  # Use integer division to reduce the number
    
    # The digits are collected in reverse order, so reverse them
    binary_digits.reverse()
    
    return "".join(binary_digits)


def decimal_to_binary_deepseek_self_repair(decimal: int) -> str:
    """
    Final robust implementation to convert decimal to binary string.
    """
    # Input validation
    if not isinstance(decimal, int):
        raise TypeError(f"Input must be an integer, got {type(decimal).__name__}")
    if decimal < 0:
        raise ValueError("Input must be a non-negative integer")
    
    if decimal == 0:
        return "0"
    
    binary_digits = []
    
    while decimal > 0:
        remainder = decimal % 2
        binary_digits.append(str(remainder))
        decimal //= 2  # Integer division
    
    binary_digits.reverse()
    
    return "".join(binary_digits)

def decimal_to_binary_gpt_self_repair(n: int) -> str:
    if not isinstance(n, int):
        raise TypeError("Input must be an integer.")
    if n < 0:
        raise ValueError("Negative numbers not supported.")
    if n == 0:
        return "0"

    bits = []
    while n > 0:
        bits.append(str(n & 1))
        n >>= 1
    return ''.join(reversed(bits))
