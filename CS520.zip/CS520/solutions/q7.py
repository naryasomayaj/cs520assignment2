from typing import List


def parse_nested_parens_gpt_chain_of_thought(paren_string: str) -> List[int]:
    """
    Given a string with multiple groups of nested parentheses separated by spaces,
    return a list containing the deepest level of nesting for each group.
    
    Example:
        input_string = "() (()) (()()) ((()))"
        → Output: [1, 2, 2, 3]
    """
    if not paren_string.strip():
        return []  # Empty input
    
    groups = paren_string.split()
    result = []

    for group in groups:
        current_depth = 0
        max_depth = 0
        for char in group:
            if char == '(':
                current_depth += 1
                max_depth = max(max_depth, current_depth)
            elif char == ')':
                current_depth -= 1
        result.append(max_depth)
    
    return result

def parse_nested_parens_deepseek_chain_of_thought(paren_string: str) -> List[int]:
    groups = paren_string.split()
    results = []
    
    for group in groups:
        current_depth = 0
        max_depth = 0
        
        for char in group:
            if char == '(':
                current_depth += 1
                max_depth = max(max_depth, current_depth)
            elif char == ')':
                current_depth -= 1
                # Note: We don't update max_depth on closing parentheses
        
        results.append(max_depth)
    
    return results

def parse_nested_parens_deepseek_self_repair(paren_string: str) -> List[int]:
    """
    Final robust implementation to parse nested parentheses and find maximum depth.
    """
    # Input validation
    if not isinstance(paren_string, str):
        raise TypeError(f"Input must be a string, got {type(paren_string).__name__}")
    
    if not paren_string.strip():
        return []  # Return empty list for empty or whitespace-only input
    
    groups = paren_string.split()
    results = []
    
    for group in groups:
        current_depth = 0
        max_depth = 0
        
        for char in group:
            if char == '(':
                current_depth += 1
                max_depth = max(max_depth, current_depth)
            elif char == ')':
                current_depth -= 1
                if current_depth < 0:
                    raise ValueError("Unbalanced parentheses detected")
        
        if current_depth != 0:
            raise ValueError("Unbalanced parentheses detected")
        
        results.append(max_depth)
    
    return results

def parse_nested_parens_gpt_self_repair(paren_string: str) -> List[int]:
    """
    Given a string with multiple groups of balanced parentheses separated by spaces,
    return a list of integers representing the maximum nesting depth for each group.

    Example:
        Input:  "(()()) ((())) ()"
        Output: [2, 3, 1]
    """

    # Step 1: Normalize whitespace
    s = paren_string.strip()
    if not s:
        return []

    # Step 2: Split by spaces and filter out empty segments
    groups = [g for g in s.split() if g]

    result = []

    for group_index, group in enumerate(groups):
        depth = 0
        max_depth = 0

        for i, ch in enumerate(group):
            if ch == '(':
                depth += 1
                max_depth = max(max_depth, depth)
            elif ch == ')':
                depth -= 1
            else:
                raise ValueError(
                    f"Invalid character '{ch}' in group {group_index+1} at position {i}"
                )

            if depth < 0:
                raise ValueError(
                    f"Unbalanced parentheses: extra ')' in group {group_index+1}"
                )

        if depth != 0:
            raise ValueError(
                f"Unbalanced parentheses: missing ')' in group {group_index+1}"
            )

        result.append(max_depth)

    return result
