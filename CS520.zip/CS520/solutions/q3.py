import math


def truncate_number_gpt_chain_of_thought(number: float) -> float:
    """
    Given a positive floating-point number, return its decimal part.
    
    Example:
        12.345 -> 0.345
        7.0 -> 0.0
        3.14159 -> 0.14159
    """
    if number < 0:
        raise ValueError("Input must be a positive number.")
    
    integer_part = int(number)
    decimal_part = number - integer_part
    return decimal_part

def truncate_number_deepseek_chain_of_thought(number: float) -> float:
    """
    Extract the decimal part of a positive floating point number.
    
        Args:
        number (float): A positive floating point number
        
    Returns:
        float: The decimal part (always between 0 and 1)
        
    Raises:
        ValueError: If input is not positive
    """
    if number < 0:
        raise ValueError("Input must be a positive number")
    
    # Extract integer part using floor
    integer_part = math.floor(number)
    
    # Calculate decimal part
    decimal_part = number - integer_part
    
    return decimal_part

def truncate_number_deepseek_self_repair(number: float) -> float:
    """
    Final robust implementation with comprehensive edge case handling.
    """
    # Input validation
    if not isinstance(number, (int, float)):
        raise TypeError(f"Input must be a number, got {type(number).__name__}")
    
    # Special float values
    if math.isnan(number):
        raise ValueError("Input cannot be NaN")
    if math.isinf(number):
        raise ValueError("Input cannot be infinity")
    
    # Check positivity
    if number < 0:
        raise ValueError(f"Input must be positive, got {number}")
        # Precision setting
    PRECISION = 14
    
    # Quick returns for common cases
    if number == 0:
        return 0.0
    
    # Check if number is effectively an integer
    if abs(number - round(number)) < 1e-12:
        return 0.0
    
    # For very large numbers, use modulo for numerical stability
    if number > 1e12:
        decimal_part = number % 1
        # Ensure result is in [0, 1)
        if decimal_part < 0:
            decimal_part += 1
        if abs(decimal_part - 1.0) < 1e-12:
            decimal_part = 0.0
            return round(decimal_part, PRECISION)
        integer_part = math.floor(number)
        decimal_part = number - integer_part
    
    # Handle floating point imprecision
    if math.isclose(decimal_part, 1.0, abs_tol=1e-12):
        decimal_part = 0.0
    elif decimal_part < 0:
        # This should not happen with positive numbers and math.floor
        # But handle for absolute safety
        decimal_part = abs(decimal_part) % 1

        # Final rounding and bounds check
    decimal_part = round(decimal_part, PRECISION)
    decimal_part = max(0.0, min(decimal_part, 1.0 - 1e-12))
    return decimal_part
def truncate_number_gpt_self_repair(number: float) -> float:

    """
    Final robust implementation for extracting decimal part.
    
    This implementation handles:
    - Input validation and type checking
    - Special float values (NaN, infinity)
    - Floating point precision issues
    - Very large and very small numbers
    - Edge cases and boundary conditions
    """
    # === INPUT VALIDATION ===
    if not isinstance(number, (int, float)):
        raise TypeError(f"Input must be a number, got {type(number).__name__}")
    
    # === SPECIAL FLOAT VALUES ===
    if math.isnan(number):
        raise ValueError("Input cannot be NaN")
    if math.isinf(number):
        raise ValueError("Input cannot be infinity")
    
    # === POSITIVITY CHECK ===
    if number < 0:
        raise ValueError(f"Input must be positive, got {number}")
    
    # === PRECISION SETTINGS ===
    PRECISION = 14
    TOLERANCE = 1e-12
    
    # === QUICK RETURNS ===
    if number == 0:
        return 0.0
    
    # Check if number is effectively an integer
    if abs(number - round(number)) < TOLERANCE:
        return 0.0
    
    # === MAIN LOGIC WITH FALLBACK STRATEGY ===
    try:
        # Primary method: math.floor approach
        return _decimal_part_primary(number, PRECISION, TOLERANCE)
    except (OverflowError, ValueError):
        # Fallback method: modulo approach
        return _decimal_part_fallback(number, PRECISION)

def _decimal_part_primary(number, precision, tolerance):
    """
    Primary method using math.floor.
    Most accurate for normal-sized numbers.
    """
    integer_part = math.floor(number)
    decimal_part = number - integer_part
    
    # Handle floating point artifacts
    if math.isclose(decimal_part, 1.0, abs_tol=tolerance):
        decimal_part = 0.0
    elif decimal_part < -tolerance:
        # This indicates a serious error for positive numbers
        raise ValueError(f"Unexpected negative decimal part: {decimal_part}")
    
    # Ensure result is in [0, 1)
    decimal_part = max(0.0, decimal_part)
    decimal_part = min(decimal_part, 1.0 - 1e-15)
    
    return round(decimal_part, precision)

def _decimal_part_fallback(number, precision):
    """
    Fallback method using modulo operator.
    More robust for very large numbers.
    """
    try:
        decimal_part = number % 1
    except OverflowError:
        # For extremely large numbers, use string conversion as last resort
        return _decimal_part_string_fallback(number, precision)
    
    # Normalize to [0, 1)
    if decimal_part < 0:
        decimal_part += 1
    elif decimal_part >= 1:
        decimal_part = 0.0
    
    # Handle near-1 values due to floating point imprecision
    if abs(decimal_part - 1.0) < 1e-12:
        decimal_part = 0.0
    
    return round(decimal_part, precision)

def _decimal_part_string_fallback(number, precision):
    """
    Last resort method using string conversion.
    Used when numerical methods fail due to extreme values.
    """
    try:
        # Convert to high-precision string
        str_rep = f"{number:.{precision}f}"
        
        if '.' not in str_rep:
            return 0.0
        
        # Extract decimal part
        decimal_str = '0.' + str_rep.split('.')[1]
        decimal_part = float(decimal_str)
        
        # Ensure it's in [0, 1)
        if decimal_part >= 1.0:
            decimal_part = 0.0
        
        return decimal_part
    except:
        # Ultimate fallback
        return 0.0

# Verification function to test multiple methods
def verify_decimal_part(number, methods=None):
    """
    Verify decimal part calculation using multiple methods.
    """
    if methods is None:
        methods = [
            ("Primary", _decimal_part_primary),
            ("Fallback", _decimal_part_fallback),
            ("String", _decimal_part_string_fallback)
        ]
    
    results = {}
    for name, method in methods:
        try:
            if name == "Primary":
                results[name] = method(number, 14, 1e-12)
            else:
                results[name] = method(number, 14)
        except Exception as e:
            results[name] = f"Error: {e}"
    
    return results