def multiply_gpt_chain_of_thought(a, b):
    """
    Given two integers a and b, return the product of their unit (last) digits.
    Assumes valid integer inputs.
    
    Example:
        a = 47, b = 52 → 7 * 2 = 14
    """
    unit_a = abs(a) % 10
    unit_b = abs(b) % 10
    return unit_a * unit_b


def multiply_deepseek_chain_of_thought(a: int, b: int) -> int:
    """
    Calculate the product of the unit digits of two integers.
    
    Args:
        a: First integer
        b: Second integer
        
    Returns:
        Integer product of the unit digits
    """
    # Extract unit digits using modulo 10
    unit_a = abs(a) % 10
    unit_b = abs(b) % 10
    
    # Calculate product
    product = unit_a * unit_b
    
    return product

def multiply_deepseek_self_repair(a: int, b: int) -> int:   
    """
    Final robust implementation to multiply unit digits of two integers.
    """
    
    unit_a = abs(a) % 10
    unit_b = abs(b) % 10
    
    return unit_a * unit_b

def multiply_gpt_self_repair(a: int, b: int) -> int:
    if not isinstance(a, int) or not isinstance(b, int):
        raise TypeError("Both inputs must be integers.")
    return (abs(a) % 10) * (abs(b) % 10)
