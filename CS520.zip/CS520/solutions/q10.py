from math import inf
from typing import List, Union


def min_cost_path_gpt_chain_of_thought(cost, m, n):
    """
    Compute the minimum cost to reach cell (m, n) from (0, 0)
    in a given cost matrix.
    
    Allowed moves: right, down, diagonal.
    
    :param cost: 2D list of non-negative numbers
    :param m: target row index
    :param n: target column index
    :return: minimum cost value (int or float)
    """
    rows = len(cost)
    cols = len(cost[0])
    
    # Create DP table
    dp = [[0 for _ in range(cols)] for _ in range(rows)]
    
    dp[0][0] = cost[0][0]
    
    # Fill first row
    for j in range(1, n + 1):
        dp[0][j] = dp[0][j - 1] + cost[0][j]
    
    # Fill first column
    for i in range(1, m + 1):
        dp[i][0] = dp[i - 1][0] + cost[i][0]
    
    # Fill remaining cells
    for i in range(1, m + 1):
        for j in range(1, n + 1):
            dp[i][j] = cost[i][j] + min(
                dp[i - 1][j],      # from top
                dp[i][j - 1],      # from left
                dp[i - 1][j - 1]   # from diagonal
            )
    
    return dp[m][n]


def min_cost_path_deepseek_chain_of_thought(cost: list[list[float]], m: int, n: int) -> float:
    """
    Find the minimum cost path from (0, 0) to (m, n) in a cost matrix.
    
    Args:
        cost: 2D list representing the cost matrix
        m: target row index (0-based)
        n: target column index (0-based)
        
    Returns:
        Minimum cost to reach (m, n) from (0, 0)
    """
    # Create a DP table to store minimum cost to reach each cell
    dp = [[0 for _ in range(n)] for _ in range(m)]
    
    # Initialize starting point
    dp[0][0] = cost[0][0]
    
    # Initialize first column (can only come from above)
    for i in range(1, m + 1):
        dp[i][0] = dp[i - 1][0] + cost[i][0]
    
    # Initialize first row (can only come from left)
    for j in range(1, n + 1):
        dp[0][j] = dp[0][j - 1] + cost[0][j]
    
    # Fill rest of the DP table
    for i in range(1, m + 1):
        for j in range(1, n + 1):
            dp[i][j] = cost[i][j] + min(dp[i - 1][j],  # from above
                                        dp[i][j - 1])  # from left
    
    return dp[m][n]

def min_cost_path_deepseek_self_repair(cost: list[list[float]], m: int, n: int) -> float:
    """
    Final robust implementation to compute minimum cost path in a cost matrix.
    """
    # Input validation
    if not isinstance(cost, list) or not all(isinstance(row, list) for row in cost):
        raise TypeError("Cost must be a 2D list")
    
    rows = len(cost)
    if rows == 0:
        raise ValueError("Cost matrix cannot be empty")
    
    cols = len(cost[0])
    for row in cost:
        if len(row) != cols:
            raise ValueError("All rows in the cost matrix must have the same length")
    
    if not (0 <= m < rows) or not (0 <= n < cols):
        raise IndexError("Target indices (m, n) are out of bounds")
    
    # Create DP table
    dp = [[0 for _ in range(cols)] for _ in range(rows)]
    
    dp[0][0] = cost[0][0]
    
    # Fill first row
    for j in range(1, cols):
        dp[0][j] = dp[0][j - 1] + cost[0][j]
    
    # Fill first column
    for i in range(1, rows):
        dp[i][0] = dp[i - 1][0] + cost[i][0]
    
    # Fill remaining cells
    for i in range(1, rows):
        for j in range(1, cols):
            dp[i][j] = cost[i][j] + min(
                dp[i - 1][j],      # from top
                dp[i][j - 1],      # from left
                dp[i - 1][j - 1]   # from diagonal
            )
    
    return dp[m][n]

Number = Union[int, float]

class MinCostPathError(Exception):
    pass

def min_cost_path_gpt_self_repair(cost: List[List[float]], m: int, n: int) -> float:
    """
    Compute the minimum cost to reach cell (m, n) from (0, 0)
    in a 2D cost matrix using allowed moves: right, down, and diagonal (down-right).

    Args:
        cost: 2D list (rows x cols) of non-negative float or int costs.
        m: target row index (0-based)
        n: target column index (0-based)

    Returns:
        Minimal total cost to reach (m, n) from (0, 0).

    Raises:
        ValueError: for invalid or non-rectangular matrices, 
                    out-of-bounds target coordinates, or empty cost.
    """

    # -------------------------
    # Validation and edge cases
    # -------------------------
    if not cost or not isinstance(cost, list) or not all(isinstance(row, list) for row in cost):
        raise ValueError("Input 'cost' must be a non-empty 2D list")

    rows = len(cost)
    cols = len(cost[0])
    if any(len(row) != cols for row in cost):
        raise ValueError("Input 'cost' matrix must be rectangular")

    if m < 0 or n < 0 or m >= rows or n >= cols:
        raise ValueError(f"Target (m={m}, n={n}) is out of bounds for matrix of size {rows}x{cols}")

    if rows == 1 and cols == 1:  # trivial case
        return cost[0][0]

    # -------------------------
    # Dynamic Programming setup
    # -------------------------
    dp = [[inf for _ in range(n + 1)] for _ in range(m + 1)]

    dp[0][0] = cost[0][0]

    # Fill first row (only from left)
    for j in range(1, n + 1):
        dp[0][j] = dp[0][j - 1] + cost[0][j]

    # Fill first column (only from top)
    for i in range(1, m + 1):
        dp[i][0] = dp[i - 1][0] + cost[i][0]

    # -------------------------
    # Fill rest of dp table
    # -------------------------
    for i in range(1, m + 1):
        for j in range(1, n + 1):
            dp[i][j] = cost[i][j] + min(
                dp[i - 1][j],     # from top
                dp[i][j - 1],     # from left
                dp[i - 1][j - 1]  # from diagonal
            )

    # Result is at target cell
    return dp[m][n]
